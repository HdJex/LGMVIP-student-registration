Student Registration Form using React JS.
